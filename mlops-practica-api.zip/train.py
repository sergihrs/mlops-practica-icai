import argparse
import json
import os

import joblib
import matplotlib.pyplot as plt
import mlflow
import mlflow.sklearn
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split


def train_model(n_estimators):
    tracking_uri = os.environ.get("MLFLOW_TRACKING_URI")
    mlflow.set_tracking_uri(str(tracking_uri))


    # Cargar el conjunto de datos desde el archivo CSV
    try:
        iris = pd.read_csv("data/iris_dataset.csv")
    except FileNotFoundError:
        print("Error: El archivo 'data/iris_dataset.csv' no fue encontrado.")

    # Dividir el DataFrame en características (X) y etiquetas (y)
    X = iris.drop("target", axis=1)
    y = iris["target"]


    # Iniciar un experimento de MLflow
    with mlflow.start_run():
        # Dividir los datos en conjuntos de entrenamiento y prueba
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42
        )
        # Inicializar y entrenar el modelo
        model = RandomForestClassifier(n_estimators=n_estimators, random_state=42)
        model.fit(X_train, y_train)
        # Realizar predicciones y calcular la precisión
        y_pred = model.predict(X_test)

        accuracy = accuracy_score(y_test, y_pred)
        # Guardar el modelo entrenado en un archivo .pkl
        joblib.dump(model, "model.pkl")
        # Registrar el modelo con MLflow
        mlflow.sklearn.log_model(model, "random-forest-model")
        # Registrar parámetros y métricas
        mlflow.log_param("n_estimators", n_estimators)
        mlflow.log_metric("accuracy", float(accuracy))
        print(f"Modelo entrenado y precisión: {accuracy:.4f}")
        print("Experimento registrado con MLflow.")

        # --- Sección de Reporte para CML ---
        # 1. Generar la matriz de confusión
        cm = confusion_matrix(y_test, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
        plt.title("Matriz de Confusión")
        plt.xlabel("Predicciones")
        plt.ylabel("Valores Reales")
        plt.savefig("confusion_matrix.png")
        cm_path = os.path.abspath("confusion_matrix.png")
        print("Matriz de confusión guardada como 'confusion_matrix.png'")
        # Registrar la matriz de confusión como artifact en MLflow
        if os.path.exists(cm_path):
            mlflow.log_artifact(cm_path)
            print(f"Matriz de confusión registrada en MLflow como artifact: {cm_path}")
        else:
            print(f"No se encontró el archivo de la matriz de confusión en {cm_path}; no se pudo registrar como artifact.")

        metrics={"accuracy": accuracy}
        with open("mlflow_metrics.json", "w") as f:
            json.dump(metrics, f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--n_estimators", type=int, default=100, help="Number of estimators for the Random Forest model")
    args = parser.parse_args()
    train_model(args.n_estimators)